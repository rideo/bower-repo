# packaged flowplayer-ipad

version: 3.2.12
web site: http://flash.flowplayer.org/plugins/javascript/ipad.html